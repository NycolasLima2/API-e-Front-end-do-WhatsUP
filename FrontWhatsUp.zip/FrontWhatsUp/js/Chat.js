async function enviarMensagem() {
  // 1. Resgatar valores dos inputs no DOM
  const telefoneDestino = document.getElementById('destinatario').value;
  const mensagem = document.getElementById('textoMensagem').value;
  
  // Correção: Selecionar por ID e pegar o .value
  const meuTelefone = document.getElementById('tel').value;
  const minhaSenhaHash = document.getElementById('senha').value;

  // 2. Montar o payload incluindo as credenciais se o servidor exigir
  const dadosMensagem = {
    meuTelefone: meuTelefone,
    minhaSenhaHash: minhaSenhaHash,
    telefoneDestino: telefoneDestino,
    mensagem: mensagem
  };

  try {
    // 3. Configurar Fetch com JSON no Body
    const url = 'http://localhost:3300/chat';

    const resposta = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json' // Informa ao servidor que o envio é JSON
      },
      body: JSON.stringify(dadosMensagem) // Converte o objeto JS para String JSON
    });

    const dadosRetorno = await resposta.json();

    // 4. Tratar o retorno da API
    if (resposta.ok) {
      alert('Status: ' + dadosRetorno.mensagem);
      document.getElementById('textoMensagem').value = ''; // Limpa o campo de mensagem
    } else {
      // Trata erros retornados pelo servidor (ex: 401 Unauthorized, 400 Bad Request)
      alert('Falha: ' + (dadosRetorno.mensagem || 'Erro ao enviar mensagem.'));
    }
  } catch (erro) {
    console.error('Erro na requisição:', erro);
    alert('Erro de conexão com o servidor.');
  }
}