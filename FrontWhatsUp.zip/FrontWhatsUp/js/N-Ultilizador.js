const Continuar = document.querySelector('#bnt-Continuar')

async function realizarRegistro() {
// 1. Capturar os valores direto do DOM
const apelido = document.getElementById('apl').value;
const senha = document.getElementById('senha').value;
const telefone = document.getElementById('tel').value;
// 2. Empacotar os dados no formato exigido pela API (form-data)
const formData = new FormData();
formData.append('apelido', apelido);
formData.append('senha', senha);
formData.append('telefone', telefone);

try {
// 3. Disparar a requisição POST para o endpoint

const resposta = await fetch('http://localhost:3300/registrar', {
method: 'POST',
body: formData
});

// Transforma a resposta do servidor em um objeto JavaScript
const dados = await resposta.json();

// Verifica se o servidor retornou 201 Created
if (resposta.ok) {
alert('Sucesso: ' + dados.mensagem);
window.location.href = "Chat.html"
} else {
// Caso ocorra o erro 409 Conflict (Utilizador Já Existe)
alert('Atenção: ' + dados.mensagem);
}
} catch (erro) {
console.error('Erro de comunicação:', erro);
alert('Falha ao conectar com o servidor da API.');
}
}

Continuar.addEventListener('click', async () => {

await realizarRegistro()

Continuar.disabled = false;
})