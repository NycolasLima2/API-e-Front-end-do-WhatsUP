const express = require('express');
const authRoute = require('./routes/auth.routes');
const cors = require('cors')

const CorsOpitions = {
    origin: 'http://localhost:3300' ,
    optionsSuccessStatus: 200
}

const APP = express();
APP.use(express.json());
APP.use(authRoute);
APP.use(cors())


const PORT = 3300;
const SERVER = "localhost";
const MSG = `Servidor online em ${SERVER}: ${PORT}`;


























APP.use(cors(CorsOptions));
APP.listen( PORT , () => console.log(MSG));