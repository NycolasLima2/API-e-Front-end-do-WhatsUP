const { Router } = require("express");
const conn = require("../DB/Connection");

const router = Router();

router.post("/auth", async (req, res) =>{
    
    const isAuth = false;
    const {Telefone, Senha } = req.query;
    const CMD = "select * from ultilizadores where Telefone = ? and Senha = ?";
    const query = await conn.query(CMD, [Telefone, Senha]);

    if(query[0].length > 0){

        isAuth = true;
    }

    res.json({
            isAuth:isAuth
        })

});


//exportamos ada rotas defenidas no arquivo.
module.exports = router;